'''
osm_highway_type_dict = {'motorway': 'motorway',
                         'motorway_link': 'motorway',
                         'trunk': 'trunk',
                         'trunk_link': 'trunk',
                         'primary': 'primary',
                         'primary_link': 'primary',
                         'secondary': 'secondary',
                         'secondary_link': 'secondary',
                         'tertiary': 'tertiary',
                         'tertiary_link': 'tertiary',
                         'residential': 'residential',
                         'unclassified': 'unclassified'}
'''

osm_railway_type_dict = {'rail': 'rail',
                         'platform': 'platform'}

link_type_no_dict = {'rail': 1, 'platform': 2, 'unclassified': 3}
default_lanes_dict = {'rail': 2, 'platform': 1, 'unclassified': 1}
default_speed_dict = {'rail': 80, 'platform': 1, 'unclassified': 100}

# default_oneway_flag_dict = {'motorway': True,'trunk':True,'primary':True,'secondary':False,'tertiary':False,'residential':False,'unclassified':False}
default_oneway_flag_dict = {'rail': True, 'platform': True, 'unclassified': False}


default_int_buffer = 20.0



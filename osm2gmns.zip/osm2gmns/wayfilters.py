# Note: we adopt the filter logic from osmnx (https://github.com/gboeing/osmnx)
# exclude links with tag attributes in the filters
filters = {}

'''
# 汽车道
filters['auto'] = {'area':['yes'],
                   'highway':['cycleway','footway','path','pedestrian','steps','track','corridor','elevator','escalator',
                              'proposed','construction','bridleway','abandoned','platform','raceway','service'],
                   'motor_vehicle':['no'],
                   'motorcar':['no'],
                   'access':['private'],
                   'service':['parking','parking_aisle','driveway','private','emergency_access']
                   }

# 自行车道
filters['bike'] = {'area':['yes'],
                   'highway':['footway','steps','corridor','elevator','escalator','motor','proposed','construction','abandoned','platform','raceway'],
                   'bicycle':['no'],
                   'service':['private'],
                   'access':['private']
                   }

# 步行道
filters['walk'] = {'area':['yes'],
                   'highway':['cycleway','motor','proposed','construction','abandoned','platform','raceway'],
                   'foot':['no'],
                   'service':['private'],
                   'access':['private']
                   }

'''

# 铁路
filters['railway'] = {'area': ["yes"],
                    'railway': ['abandoned', 'construction', 'disused', 'funicular', 'light_rail', 'miniature',
                                'monorail', 'narrow_gauge', 'preserved', 'subway', 'tram'],
                    'service':['private'],
                    'access':['private']
                    }


def getAllowableAgentType(way):
    allowable_agent_type_list = []
    for agent_type, m_filter in filters.items():
        allowed = True
        for tag, exclude_list in m_filter.items():
            if eval(f'way.{tag} in exclude_list'):
                allowed = False
                break

        if allowed: allowable_agent_type_list.append(agent_type)
    return allowable_agent_type_list
